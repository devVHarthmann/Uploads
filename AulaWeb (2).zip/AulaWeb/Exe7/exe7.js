numA = parseInt(prompt("Insira o número A: "))
numB = parseInt(prompt("Insira o número B: "))
if (numA > numB) {
    document.getElementById('mensagem').innerHTML = `O número ${numA} é maior que o número ${numB}`
} else if (numA < numB) {
    document.getElementById('mensagem').innerHTML = `O número ${numB} é maior que o número ${numA}`
} else {
    document.getElementById('mensagem').innerHTML = `O número ${numA} é igual ao número ${numB}`
}