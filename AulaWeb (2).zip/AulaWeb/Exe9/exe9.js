ano = parseInt(prompt("Insira um ano: "))
if (ano % 400 == 0 || ano % 4 == 0 && ano % 100 != 0) {
    document.getElementById('mensagem').innerHTML = "É bissexto"
} else {
    document.getElementById('mensagem').innerHTML = "Não é bissexto"
}