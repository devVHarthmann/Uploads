nota = parseFloat(prompt("Insira uma nota de 0 a 100: "))

if (nota >= 70) {
    document.getElementById('mensagem').innerHTML = `Aprovado`
} else if (nota >= 50 && nota<= 69) {
    document.getElementById('mensagem').innerHTML = `Recuperação`
} else {
    document.getElementById('mensagem').innerHTML = `Reprovado`
}