 largura = parseFloat(prompt('Informe a largura do retângulio'))
 altura = parseFloat(prompt('Informe a altura do retângulio'))
 area = largura * altura;
 document.getElementById('mensagem').innerHTML = `A altura do retângulo é ${altura}m, a largura é ${largura}m e a área é ${area} `