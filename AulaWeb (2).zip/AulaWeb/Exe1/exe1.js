    var nome = prompt("Informe seu nome")
    document.getElementById('mensagem').innerHTML = `Bem vindo ao seu primeiro exercício, ${nome}`